# NSK Bank - Top 1% Fintech Project

Features:
- React + Component Architecture
- Firebase Auth + Firestore
- Role-based dashboards (Admin & Customer)
- AI Fraud Detection (pattern + threshold)
- Analytics Dashboard (Chart.js)
- PDF Statements
- Dark Premium UI
- Fully Serverless

Run:
npm install
npm start
