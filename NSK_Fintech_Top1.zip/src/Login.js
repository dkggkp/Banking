import React, {useState} from 'react';
import Dashboard from './Dashboard';

function Login(){
  const [user,setUser]=useState(null);

  if(user) return <Dashboard user={user}/>

  return (
    <div style={{textAlign:"center"}}>
      <h1>NSK Bank Login</h1>
      <button onClick={()=>setUser({role:"admin"})}>Login as Admin</button>
      <button onClick={()=>setUser({role:"customer"})}>Login as Customer</button>
    </div>
  )
}
export default Login;
