import React from 'react';
import { Bar } from 'react-chartjs-2';

function Analytics({history}){
  let credit=0, debit=0;
  history.forEach(h=>{
    if(h.type==="deposit") credit+=h.amt;
    else debit+=h.amt;
  });

  const data={
    labels:["Credits","Debits"],
    datasets:[{data:[credit,debit]}]
  }

  return <Bar data={data}/>
}
export default Analytics;
