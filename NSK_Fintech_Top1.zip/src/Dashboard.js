import React, {useState} from 'react';
import Analytics from './components/Analytics';

function Dashboard({user}){
  const [balance,setBalance]=useState(10000);
  const [history,setHistory]=useState([]);

  const fraudCheck=(amt)=>{
    if(amt>50000) return "⚠ High Risk";
    if(history.length>5 && amt>20000) return "⚠ Pattern Risk";
    return "Safe";
  }

  const deposit=(amt)=>{
    alert(fraudCheck(amt));
    setBalance(balance+amt);
    setHistory([...history,{type:"deposit",amt}]);
  }

  const withdraw=(amt)=>{
    if(balance<amt) return alert("Insufficient");
    alert(fraudCheck(amt));
    setBalance(balance-amt);
    setHistory([...history,{type:"withdraw",amt}]);
  }

  return (
    <div>
      <h1>{user.role.toUpperCase()} Dashboard</h1>
      <h2>Balance: ₹{balance}</h2>
      <button onClick={()=>deposit(60000)}>Deposit</button>
      <button onClick={()=>withdraw(2000)}>Withdraw</button>

      <Analytics history={history}/>
    </div>
  )
}
export default Dashboard;
